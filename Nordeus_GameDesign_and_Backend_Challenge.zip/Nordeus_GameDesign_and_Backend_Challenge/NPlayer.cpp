#include "Test/NPlayer.h"

NPlayer::NPlayer()
{
}

NPlayer::~NPlayer()
{
}
